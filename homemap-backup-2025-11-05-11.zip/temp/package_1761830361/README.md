# Gauge Widget Package

Visual gauge widget with rotating needle for displaying sensor values (0-100%).

## Features

- Smooth needle rotation based on value
- Colored zones (green/yellow/red)
- Expression-based rendering
- SVG manipulation for internal element styling

## Compatibility

- HomeMap v0.1.7 or later
- Device types: com.fibaro.multilevelSensor, com.fibaro.powerMeter

## Installation

1. Download the .hwp file
2. In HomeMap, go to Settings → Packages
3. Click "Install Package" and select the file
4. The widget will be available immediately

## Usage

The gauge widget automatically applies to multilevelSensor devices.
You can customize the mapping in Settings → Widget Mappings.

## License

MIT License
